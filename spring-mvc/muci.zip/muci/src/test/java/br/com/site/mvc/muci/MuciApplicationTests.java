package br.com.site.mvc.muci;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuciApplicationTests {

	@Test
	void contextLoads() {
	}

}
