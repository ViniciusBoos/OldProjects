package br.com.site.mvc.muci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MuciApplication {

	public static void main(String[] args) {
		SpringApplication.run(MuciApplication.class, args);
	}

}
